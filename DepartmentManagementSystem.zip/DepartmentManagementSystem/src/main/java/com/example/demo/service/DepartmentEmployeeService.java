package com.example.demo.service;

import com.example.demo.dto.DepartmentManagmentDto;

public interface DepartmentEmployeeService {
	public void saveDepatmentandEmployee(DepartmentManagmentDto dto);
}
