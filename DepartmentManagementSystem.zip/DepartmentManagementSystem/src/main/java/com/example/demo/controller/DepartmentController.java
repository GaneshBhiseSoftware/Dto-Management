package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.DepartmentManagmentDto;
import com.example.demo.service.DepartmentEmployeeService;

@RestController
public class DepartmentController {
	@Autowired
	DepartmentEmployeeService service;

	@PostMapping("department")
	public String addDepartment(@RequestBody DepartmentManagmentDto dto) {
		service.saveDepatmentandEmployee(dto);
		return "added";

	}
}
