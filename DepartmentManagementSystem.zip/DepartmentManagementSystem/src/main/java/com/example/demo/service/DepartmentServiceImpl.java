package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dto.DepartmentManagmentDto;
import com.example.demo.entity.Department;
import com.example.demo.entity.EmployeeDetails;
import com.example.demo.repository.DepartmentRepository;

@Service
public class DepartmentServiceImpl implements DepartmentEmployeeService {

	@Autowired
	DepartmentRepository repository;

	@Override
	public void saveDepatmentandEmployee(DepartmentManagmentDto dto) {
		Department department = new Department();
		department.setdName(dto.getDeptName());
		List<EmployeeDetails> empList = dto.getEmpList();

		for (EmployeeDetails e : empList) {
			e.setDepartment(department);
		}
		department.seteList(empList);
		repository.save(department);
	}
}
