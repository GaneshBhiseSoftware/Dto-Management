package com.example.demo.dto;

import java.util.List;

import com.example.demo.entity.EmployeeDetails;

public class DepartmentManagmentDto {

	private String deptName;
	private List<EmployeeDetails> empList;

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public List<EmployeeDetails> getEmpList() {
		return empList;
	}

	public void setEmpList(List<EmployeeDetails> empList) {
		this.empList = empList;
	}

}
